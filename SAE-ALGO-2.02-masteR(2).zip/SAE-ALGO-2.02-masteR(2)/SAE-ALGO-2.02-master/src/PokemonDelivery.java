import java.util.*;

public class PokemonDelivery {
    private Map<String, Membre> membres = new HashMap<>();
    private List<Vente> ventes = new ArrayList<>();
    private Map<String, Map<String, Integer>> distances = new HashMap<>();

    public void ajouterDistance(String ville1, String ville2, int d) {
        distances.putIfAbsent(ville1, new HashMap<>());
        distances.putIfAbsent(ville2, new HashMap<>());
        distances.get(ville1).put(ville2, d);
        distances.get(ville2).put(ville1, d);
    }
    public int getDistance(String v1, String v2) {
        return distances.get(v1).get(v2);
    }
    private Map<String, List<String>> Graphe() {
        Map<String, List<String>> graphe = new HashMap<>();
        for(Vente vente : ventes) {
            String villeVendeur = membres.get(vente.getVendeur()).getVille();
            String villeAcheteur = membres.get(vente.getAcheteur()).getVille();

            graphe.putIfAbsent(villeVendeur, new ArrayList<>());
            graphe.get(villeVendeur).add(villeAcheteur);

        }
        return graphe;
    }
    public List<String> triTopologique() {
        Map<String, List<String>> graph1= Graphe();
        Map<String, Integer> degreEntrant= new HashMap<>();
        Set<String> villes = new HashSet<>();

        for (Vente vente : ventes ) {
            String v1 = membres.get(vente.getVendeur()).getVille();
            String v2 = membres.get(vente.getAcheteur()).getVille();
            villes.add(v1);
            villes.add(v2);
        }
        for (String ville : villes) {
            degreEntrant.put(ville, 0);
        }
        for(List<String> voisins : graph1.values()) {
            for(String voisin : voisins) {
                degreEntrant.put(voisin, degreEntrant.get(voisin) + 1);

            }
        }
        Queue<String>file = new LinkedList<>();
        }
}
