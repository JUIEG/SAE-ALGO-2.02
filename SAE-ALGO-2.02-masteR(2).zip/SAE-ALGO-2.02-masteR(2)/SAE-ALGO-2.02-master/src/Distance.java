public class Distance {
    private String ville1;
    private String ville2;
    private int km;

    public Distance(String ville1, String ville2, int km) {

    }
}
