public class Distance {
}
